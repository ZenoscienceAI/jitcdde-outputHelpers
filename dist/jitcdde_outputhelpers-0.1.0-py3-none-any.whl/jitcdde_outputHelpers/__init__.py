__version__ = "0.1.0"
from .CustomJiTCDDE import customjitcdde